package com.example.to_donote;


import androidx.cardview.widget.CardView;

public class task_card {
    private String title;
    private String description;
    private boolean checked;
    CardView card;

    public task_card(String title, String description) {
        this.title = title;
        this.description = description;
        this.checked = false;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }
}