package com.example.to_donote;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class card_adapter extends RecyclerView.Adapter<card_adapter.CardViewHolder> {

    private final List<task_card> cardTaskList;
    private OnTaskCardClickListener onTaskCardClickListener;

    public card_adapter(List<task_card> cardTaskList) {
        this.cardTaskList = cardTaskList;
    }

    // Interface for click events on task_card items
    public interface OnTaskCardClickListener {
        void onTaskCardClick(task_card taskCard, int position);
    }

    public void setOnTaskCardClickListener(OnTaskCardClickListener listener) {
        onTaskCardClickListener = listener;
    }

    @NonNull
    @Override
    public CardViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.task_card, parent, false);
        return new CardViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CardViewHolder holder, int position) {
        task_card taskCard = cardTaskList.get(holder.getAdapterPosition());

        holder.checkBox.setChecked(taskCard.isChecked());
        holder.checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> taskCard.setChecked(isChecked));

        holder.titleTextView.setText(taskCard.getTitle());
        holder.descriptionTextView.setText(taskCard.getDescription());
        holder.dateTime.setText(taskCard.getDateTime());

        // Set long click listener for the main card (root view)
        holder.itemView.findViewById(R.id.card).setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                // Handle the click event for the main card
                if (onTaskCardClickListener != null) {
                    onTaskCardClickListener.onTaskCardClick(taskCard, holder.getAdapterPosition());
                }
                return true;
            }
        });


        holder.titleTextView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                // Handle the long click event for the titleTextView
                if (onTaskCardClickListener != null) {
                    onTaskCardClickListener.onTaskCardClick(taskCard, holder.getAdapterPosition());
                }
                return true; // Return true to indicate that the long click event is consumed
            }
        });

        holder.descriptionTextView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                // Handle the long click event for the descriptionTextView
                if (onTaskCardClickListener != null) {
                    onTaskCardClickListener.onTaskCardClick(taskCard, holder.getAdapterPosition());
                }
                return true; // Return true to indicate that the long click event is consumed
            }
        });
    }

    @Override
    public int getItemCount() {
        return cardTaskList.size();
    }

    public static class CardViewHolder extends RecyclerView.ViewHolder {
        CheckBox checkBox;
        TextView titleTextView;
        TextView descriptionTextView;
        TextView dateTime;

        public CardViewHolder(@NonNull View itemView) {
            super(itemView);
            checkBox = itemView.findViewById(R.id.firstCheckBox);
            titleTextView = itemView.findViewById(R.id.titleTextView);
            descriptionTextView = itemView.findViewById(R.id.descriptionTextView);
            dateTime = itemView.findViewById(R.id.dateTime);
        }
    }
}
